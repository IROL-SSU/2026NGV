# 2. BehaviorScript + On MessageBus Event

**목표:** Guard의 BehaviorScript가 contact를 검출하고, Action Graph의 **On MessageBus Event**가 그 event를 받아 conveyor를 정지시킵니다. **이 예제의 Action Graph에는 Script Node가 없습니다.**

**시작:** 예제 1을 완료한 작업용 scene에서 **Stop**합니다.

## 2-1. Guard에 BehaviorScript 지정

1. Extensions에서 **Python Behavior Scripting** 기능을 활성화합니다. 필요한 extension은 `omni.behavior.scripting.core`, `omni.behavior.scripting.ui`입니다.
2. Stage에서 `/World/Lane01/Guard`를 선택합니다.
3. Property의 **Python Scripting**을 펼칩니다. 항목이 없으면 **Add → Python Scripting**으로 추가합니다.
4. **Python Scripting → Scripts**에 다음 파일을 지정합니다.

   `C:/Users/dhlee/NGV_work/NGV_lab/day2_am/contact_control/behaviors/guard_contact.py`

5. 이 예제의 BehaviorScript 실행을 묻는 **Warning**이 나오면 **Yes**를 선택합니다. 새 stage를 열 때 이 실행 승인을 다시 확인합니다.

**→ 정상 표시:** Guard의 Scripts에 `guard_contact.py`가 등록되어 있습니다.

이 script는 Guard가 포함된 **CONTACT_FOUND**를 검출할 때 다음 event를 보냅니다.

| 항목 | 값 |
|---|---|
| Event Name | `ngv.tutorial.guard_contact` |
| payload `guard` | `/World/Lane01/Guard` |
| payload `other` | Guard와 접촉한 rigid body의 prim path |
| payload `contact` | `True` |

이 예제에서는 event를 받았다는 사실만으로 정지합니다. payload를 받는 추가 output port는 만들지 않아도 됩니다.

## 2-2. contact 수신 node 교체

1. 예제 1의 `OnGuardContact`를 제거합니다. `StopOnContact`와 나머지 속도 제어 부분은 유지합니다.
2. Nodes에서 **On MessageBus Event**를 추가하고 이름을 `OnBehaviorContact`로 정합니다.
3. **Event Name**에 `ngv.tutorial.guard_contact`를 정확히 입력합니다.
4. **Only Simulate On Play**는 `True`로 둡니다.
5. 다음 한 개의 execution 선을 연결합니다.

| 출발 | 도착 |
|---|---|
| On MessageBus Event · **Received** | `StopOnContact` · Exec In |

**→ 정상 표시:** Graph의 contact 입력 부분이 On Contact Event에서 On MessageBus Event로 바뀝니다.

**Received는 bool이 아니라 execution 신호입니다.** `StopOnContact`는 이 신호를 받으면 Value에 지정된 `False`를 `LabRunEnabled` 변수에 기록합니다. 접촉 전에는 `RunOnStart`가 기록한 `True`가 유지됩니다.

## 2-3. 공통 제어 부분 확인

| 확인할 곳 | 설정 / 연결 |
|---|---|
| `StopOnContact`, `RunOnStart`, `AutoRunEnabled` · Graph | `/World/Graphs/Lane01ActionGraph` |
| 위 세 node · Variable Name | `LabRunEnabled` |
| `StopOnContact` · Value | bool `False` |
| `OnSimulationStart` | Event Name = `Simulation Start Play`, Only Simulate On Play = `True` |
| `RunOnStart` | 같은 변수에 `True` 기록 |
| `AutoRunEnabled` · Value | `LabSelectSpeed` · Condition |
| `LabSelectSpeed` · Result | 세 Conveyor Belt · Velocity |
| On Playback Tick | 세 Conveyor Belt의 On Step과 Delta에 기존 연결 유지 |

**→ 정상 표시:** BehaviorScript는 event 전송을 담당하고, 속도 선택과 conveyor 제어는 Action Graph에서 처리합니다.

## 2-4. 실행 확인

**처음 구성할 때 속도 설정:** **Stop** 상태에서 Lane01의 세 conveyor `Rollers`의 `Surface Velocity`와 `Surface Angular Velocity`를 모두 `(0, 0, 0)`으로 둡니다. 곡선 구간 `conveyor_belt_02`는 **Curved = True**, **Direction = `(0, 0, -38.197186)`**입니다. Play 중에는 graph가 surface velocity를 갱신합니다. 접촉 후에는 graph의 Velocity뿐 아니라 세 Rollers의 실제 surface velocity 두 값도 모두 0이어야 합니다.

1. **Stop** 상태에서 가운데 직선 conveyor 위의 **주황색 제품 box**를 확인합니다. 없으면 공통 준비의 `lab.add_demo_box()`를 실행합니다.
2. **Play**합니다. **→ Velocity = `1.0`이고, box가 conveyor를 따라 이동합니다.**
3. box가 Guard에 닿습니다. **→ Velocity = `0.0`, box 정지.**
4. **Stop**하면 box가 시작 위치로 돌아옵니다. 다시 **Play**합니다. **→ 다시 `1.0`.**

접촉이 풀릴 때 재가동하는 event는 보내지 않습니다. 첫 접촉 후 정지를 유지하는 동작은 예제 1과 같습니다.

## 문제 해결

| 증상 | 확인할 곳 |
|---|---|
| Python Scripting 항목이 없음 | `omni.behavior.scripting.ui` 활성화 여부 |
| script는 등록됐는데 contact 후에도 운전 | script 실행 Warning에서 Yes를 눌렀는지, Scripts 파일 경로가 맞는지 확인 |
| event를 보내지만 graph가 반응하지 않음 | Event Name 철자와 대소문자가 양쪽 모두 `ngv.tutorial.guard_contact`인지 확인 |
| contact 전에도 정지 | `RunOnStart` True와 `StopOnContact` False가 뒤바뀌지 않았는지 확인 |
| node를 선택한 뒤 Variable Name이 비어 있음 | Read/Write Variable 세 node의 Graph를 먼저 지정하고 Variable Name을 다시 선택 |
| Velocity는 0인데 box 아래 conveyor가 계속 움직임 | 곡선 Rollers의 잔류 Surface Velocity를 0으로 수정하고 위 속도 설정 확인 |
| 원래 On Contact Event도 남아 있음 | `OnGuardContact`를 제거해 이번 실습의 event 경로 하나만 사용 |

**기억할 것:** BehaviorScript는 prim에서 실행되고, On MessageBus Event는 그 script가 보낸 이름 있는 event를 Action Graph로 가져옵니다.
