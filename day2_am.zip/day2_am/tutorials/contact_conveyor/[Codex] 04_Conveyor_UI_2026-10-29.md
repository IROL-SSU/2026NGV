# 4. FloatDrag UI로 속도·가속·감속 조절

**목표:** Extension 창의 숫자를 좌우로 drag하여 Run Speed, Stop Speed, Acceleration, Deceleration을 바꿉니다. 같은 Action Graph가 contact 상태를 판단하고, `RampSpeed`가 실제 Velocity를 부드럽게 변경합니다.

**시작:** 예제 1, 2, 3 중 하나의 완성 graph를 열고 **Stop**합니다. 이 예제는 속도 변화 계산에 Script Node를 사용합니다.

## 4-1. Extension 켜기

1. **Window → Extensions**를 엽니다.
2. Extension 검색 경로에 다음 폴더를 추가합니다. 이미 등록되어 있으면 생략합니다.

   `C:/Users/dhlee/NGV_work/NGV_lab/day2_am/extensions`

3. **NGV Conveyor Control**을 검색하여 활성화합니다.
4. 같은 이름의 창이 열립니다. 닫았다면 **Window → NGV Conveyor Control**로 다시 엽니다.
5. **Connect Ramp**를 누릅니다.

**→ 정상 표시:** `Connected. Play: accelerate; contact: decelerate.`가 표시되고 graph에 `RampSpeed` node가 생깁니다.

기존 `NGV_Process_UI`와 별도의 extension입니다. 설치 폴더는 `extensions/ngv.conveyor_control`입니다.

## 4-2. 네 값을 설정

숫자 위에서 마우스를 **좌우로 drag**합니다. 숫자를 **double-click**하면 직접 입력할 수 있습니다.

| UI 항목 | 시작 값 | 이번 실습에서 하는 일 |
|---|---:|---|
| Run Speed | `1.00 m/s` | contact 전 목표 속도 |
| Stop Speed | `0.00 m/s` | contact 후 목표 속도 |
| Acceleration | `0.50 m/s²` | 목표 속도가 더 클 때 증가 속도 |
| Deceleration | `2.00 m/s²` | 목표 속도가 더 작을 때 감소 속도 |

**→ 정상 표시:** drag할 때 창 아래에 `Applied: ...`가 표시됩니다. graph 값에도 즉시 반영됩니다.

**Stop Speed = 0**이어야 완전히 정지합니다. `0.2`로 바꾸면 contact 후 `0.2 m/s`로 저속 운전합니다. Acceleration 또는 Deceleration을 `0`으로 두면 해당 방향의 속도 변경은 즉시 적용됩니다.

## 4-3. graph 연결 확인

`Connect Ramp`가 다음 연결을 만듭니다. 수동으로 선을 다시 연결할 필요는 없습니다.

| 출발 node · port | 도착 node · port |
|---|---|
| `LabSelectSpeed` · Result | `RampSpeed` · `targetVelocity` |
| On Playback Tick · Delta Seconds | `RampSpeed` · `deltaSeconds` |
| On Playback Tick · Time | `RampSpeed` · `simulationTime` |
| `RampSpeed` · `velocity` | 세 Conveyor Belt · Velocity |
| `RampSpeed` · Exec Out | 세 Conveyor Belt · On Step |

예제 1·2에서는 **Tick → RampSpeed → Conveyor Belt** 순서입니다. 예제 3에서는 **Tick → ContactEventLatch → RampSpeed → Conveyor Belt** 순서입니다. 각 node가 자신의 값을 갱신한 뒤 다음 node를 실행합니다.

| UI 값 | 실제 연결 위치 |
|---|---|
| Run Speed | `LabRunSpeed.inputs:value` |
| Stop Speed | `LabStopSpeed.inputs:value` |
| Acceleration | `RampSpeed.inputs:acceleration` |
| Deceleration | `RampSpeed.inputs:deceleration` |

## 4-4. 실행 확인

1. **Stop** 상태에서 가운데 직선 conveyor 위의 **주황색 제품 box**를 확인합니다. 없으면 공통 준비의 `lab.add_demo_box()`를 실행합니다.
2. 네 값을 4-2절의 시작 값으로 맞추고 **Play**합니다. **→ Velocity가 `0`에서 `1`까지 약 2초 동안 증가하고, box가 conveyor를 따라 이동합니다.**
3. box가 Guard에 닿으면 **→ Velocity가 서서히 `0`으로 감소합니다.** box의 출발 위치부터 Guard까지 이동하는 동안 가속과 감속을 차례로 볼 수 있습니다.
4. **Stop**합니다. **→ box가 시작 위치로 돌아옵니다.** **Deceleration**을 `0.50`으로 낮추고 다시 **Play**합니다. **→ contact 후 Velocity가 `0`이 되기까지 더 오래 걸립니다.**
5. 다시 **Stop**하고 **Run Speed** 또는 **Acceleration**을 좌우로 drag한 뒤 **Play**하여 차이를 확인합니다. contact 전 운전 중에도 drag할 수 있습니다.

속도가 `1 m/s`인 상태에서 Deceleration이 `2 m/s²`이면 conveyor의 Velocity가 `0`이 되기까지 약 **0.5초**입니다. box는 Guard에 막혀 먼저 멈출 수 있으므로 감속은 node의 **Velocity**로 확인합니다. 시간은 simulation time 기준입니다.

## 4-5. 연결 해제·복구

- graph에서 값을 직접 바꿨으면 **Refresh from Graph**를 눌러 UI에 다시 표시합니다.
- **Stop → Remove Ramp**를 누르면 contact 시 속도가 즉시 바뀌는 원래 graph로 돌아갑니다.
- 다른 예제 mode로 바꾸기 전에도 **Stop → Remove Ramp**를 먼저 실행합니다. 새 mode를 연 뒤 **Connect Ramp**를 다시 누릅니다.
- 완성 결과를 보관하려면 작업용 scene을 저장합니다.

## 문제 해결

| 증상 | 확인할 곳 |
|---|---|
| Extensions 검색에 안 나옴 | 검색 경로가 `.../day2_am/extensions`인지 확인 |
| Connect Ramp에서 Stop 안내 | Pause가 아니라 **Stop**한 뒤 다시 클릭 |
| graph / Select node가 없다는 안내 | 예제 1–3의 완성 scene을 먼저 열기 |
| contact 후 완전히 안 멈춤 | Stop Speed를 `0.00`으로 설정 |
| 가속·감속이 보이지 않음 | 해당 값이 `0`인지, RampSpeed가 연결됐는지 확인 |
| UI 값이 scene과 다름 | **Refresh from Graph** 클릭 |

구현 코드는 `ngv/conveyor_control/extension.py`의 FloatDrag, `graph.py`의 graph 연결, `ramp_script.py`의 속도 계산으로 나뉩니다. 이 실습 scene의 단위는 `1 unit = 1 m`입니다.
