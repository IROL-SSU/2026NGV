# 1. On Contact Event로 conveyor 정지

**목표:** Play하면 conveyor가 움직이고, 제품이 Guard에 처음 닿으면 세 conveyor가 함께 멈춥니다. Script Node는 사용하지 않습니다.

**시작:** 공통 준비에서 만든 작업용 scene의 `/World/Graphs/Lane01ActionGraph`를 엽니다. Timeline은 **Stop** 상태로 둡니다. 이미 같은 이름의 node가 있으면 그 node를 재사용합니다.

**먼저 확인:** 가운데 직선 conveyor 위에 **주황색 제품 box**가 보여야 합니다. 없으면 공통 준비의 import를 실행한 뒤 **Stop** 상태에서 `lab.add_demo_box()`를 실행합니다.

먼저 Stage에서 `/World/Lane01/Guard`를 선택합니다. Property에서 **Contact Reporter**를 확인하고 **Threshold = `0.0`**으로 둡니다. 항목이 없으면 **Add → Physics → Contact Reporter**로 추가합니다. 이 scene의 Guard는 Collider와 Kinematic Rigid Body가 설정되어 있습니다.

## 1-1. 기존 속도 선택 부분 확인

Nodes 목록에서 **Constant Float** 두 개와 **Select If** 하나를 만듭니다. 이름과 값을 다음처럼 설정합니다.

| Node | 값 | 역할 |
|---|---:|---|
| `LabRunSpeed` — Constant Float | `1.0` | 접촉 전 속도 |
| `LabStopSpeed` — Constant Float | `0.0` | 접촉 후 속도 |
| `LabSelectSpeed` | Select If | bool 상태에 따라 두 속도 중 하나 선택 |

`LabSelectSpeed`의 **If True**에는 `LabRunSpeed`, **If False**에는 `LabStopSpeed`를 연결합니다. 기존 수동 `LabRunEnabled`가 **Condition**에 연결되어 있으면 그 연결을 끊습니다.

**→ 정상 표시:** 속도 두 개와 Select If는 남아 있고, Condition만 새 입력을 받을 상태입니다.

## 1-2. 운전 상태를 저장하는 bool 생성

1. Action Graph 왼쪽 **Variables** 탭에서 **Add**를 누릅니다.
2. 변수 **Name**을 `LabRunEnabled`, **Type**을 `bool`, **Default Value**를 `True`로 설정합니다. 이미 있으면 새로 만들지 않고 그 변수를 사용합니다.
3. 변수를 canvas에 drag합니다. **READ VARIABLE NODE**를 선택하고 node 이름을 `AutoRunEnabled`로 정합니다.
4. 같은 변수를 두 번 더 drag하여 **WRITE VARIABLE NODE** 두 개를 만듭니다.
5. 두 Write Variable의 이름과 Value를 아래처럼 정합니다.

| Node 이름 | Variable Name | Value |
|---|---|---|
| `RunOnStart` | `LabRunEnabled` | `True` |
| `StopOnContact` | `LabRunEnabled` | `False` |

**→ 정상 표시:** bool 변수는 하나이고, 이 변수에 연결된 Read node 하나와 Write node 두 개가 있습니다.

## 1-3. 시작 event와 contact event 연결

Nodes 목록에서 **On Stage Event**, **On Contact Event**를 추가하고 다음처럼 설정합니다.

| Node 이름 | Node type / 설정 |
|---|---|
| `OnSimulationStart` | On Stage Event, Event Name = `Simulation Start Play` |
| `OnGuardContact` | On Contact Event, Body Paths = `/World/Lane01/Guard` |

On Contact Event는 `omni.physx.graph.OnContactEventBasic`입니다. **Found Exec Out**, **Lost Exec Out**이 있는 node를 사용합니다.

다음 순서로 선을 연결합니다.

| 출발 node · port | 도착 node · port |
|---|---|
| `OnSimulationStart` · Exec Out | `RunOnStart` · Exec In |
| `OnGuardContact` · **Found Exec Out** | `StopOnContact` · Exec In |
| `AutoRunEnabled` · Value | `LabSelectSpeed` · Condition |
| `LabRunSpeed` · Value | `LabSelectSpeed` · If True |
| `LabStopSpeed` · Value | `LabSelectSpeed` · If False |
| `LabSelectSpeed` · Result | 세 Conveyor Belt node의 Velocity |

**Lost Exec Out은 연결하지 않습니다.** 접촉이 잠깐 풀려도 정지 상태를 유지합니다. 재시작은 **Stop → Play**로 합니다.

> **Found Exec Out은 bool이 아닙니다.** 접촉 순간에 Write Variable을 실행하는 신호입니다. 접촉 전부터 유지할 `True` 값은 `LabRunEnabled` 변수에 저장합니다.

## 1-4. conveyor의 매 frame 실행 유지

아래 연결은 기존 graph 그대로 유지합니다.

| 출발 | 도착 |
|---|---|
| On Playback Tick · Tick | 세 Conveyor Belt · On Step |
| On Playback Tick · Delta Seconds | 세 Conveyor Belt · Delta |

세 node는 `conveyor_belt`, `conveyor_belt_01`, `conveyor_belt_02`입니다. **Enabled는 True**로 둡니다. contact event를 On Step 대신 연결하지 않습니다. conveyor는 매 frame 실행하면서 Velocity를 갱신해야 합니다.

## 1-5. 실행 확인

1. **Stop** 상태에서 가운데 직선 conveyor 위의 **주황색 제품 box**를 확인합니다.
2. **Play**합니다. **→ 세 conveyor의 Velocity = `1.0`이고, box가 직선 → 곡선 conveyor를 따라 이동합니다.**
3. box가 `/World/Lane01/Guard`에 닿을 때까지 기다립니다. **→ 세 Velocity = `0.0`, box 정지.**
4. 그대로 기다립니다. **→ 접촉이 잠깐 풀려도 `0.0` 유지.**
5. **Stop**합니다. **→ box가 시작 위치로 돌아옵니다.** 다시 **Play**하면 Velocity = `1.0`으로 운전합니다.

이 예제는 Guard 접촉으로 Lane01의 세 conveyor를 함께 정지시킵니다. 한 conveyor만 제어하려면 Result를 그 Conveyor Belt의 Velocity에만 연결합니다.

## 문제 해결

| 증상 | 확인할 곳 |
|---|---|
| box가 보이지 않음 | 공통 준비를 실행했는지 확인. **Stop** 상태에서 `lab.add_demo_box()`로 제품 box를 다시 생성 |
| 접촉해도 계속 움직임 | `OnGuardContact` Body Paths가 정확한지, Found Exec Out이 `StopOnContact`에 연결됐는지 확인 |
| contact event 자체가 없음 | Guard에 Collider, Rigid Body, PhysX Contact Report API가 있는지 확인. 이 scene은 Kinematic Rigid Body이며 Contact Report Threshold = `0.0` 사용 |
| Play 직후부터 멈춤 | `RunOnStart` Value = True, Event Name = `Simulation Start Play`, If True = Run Speed 확인 |
| 화면에서 속도를 바꿨는데 conveyor가 반응하지 않음 | On Playback Tick의 Tick/Delta 연결, Conveyor Belt의 Enabled 확인 |
| ConstantFloat의 `outputs:value`가 없다고 표시됨 | Python으로 연결할 때 ConstantFloat의 Value는 `inputs:value`. 화면에서는 Value 출력으로 보임 |

**기억할 것:** event는 상태를 바꾸고, bool 변수는 그 상태를 계속 유지합니다.
