# 3. Script Node에서 BehaviorScript event 받기

**목표:** Guard의 BehaviorScript가 보낸 event를 **Script Node**가 받고, 하나의 bool output `runEnabled`로 conveyor의 운전·정지를 제어합니다.

**시작:** 예제 2를 완료한 작업용 scene에서 **Stop**합니다. Guard의 `guard_contact.py`는 그대로 사용합니다.

## 3-1. event를 받는 부분 교체

예제 2의 다음 node를 제거합니다.

- On MessageBus Event (`OnBehaviorContact`)
- `StopOnContact`, `RunOnStart`, `OnSimulationStart`, `AutoRunEnabled`

`LabRunSpeed`, `LabStopSpeed`, `LabSelectSpeed`, On Playback Tick, 세 Conveyor Belt는 유지합니다.

**→ 정상 표시:** Select If의 Condition이 비어 있습니다. 이번에는 Script Node의 bool output이 들어갑니다.

## 3-2. Script Node와 bool output 만들기

1. Nodes에서 **Script Node**를 추가합니다. 이름을 `ContactEventLatch`로 정합니다.
2. Property에서 **Use Script File**을 켭니다.
3. **Script File Path**에 아래 파일을 지정합니다.

   `C:/Users/dhlee/NGV_work/NGV_lab/day2_am/contact_control/nodes/contact_event_latch.py`

4. **Add Attribute...**를 누르고 다음 output을 추가합니다.

| 항목 | 값 |
|---|---|
| Name | `runEnabled` |
| Port Type | `Output` |
| Data Type | `bool` |

5. **Play 전에 두 종류의 실행 승인을 모두 확인합니다.** Guard의 Python script 실행 **Warning**은 stage마다, **ScriptNode Warning**은 Isaac Sim 앱 session마다 별도로 적용됩니다. 이 실습 script의 각 Warning에서 **Yes**를 선택합니다. 같은 앱 session에서 이미 승인한 ScriptNode Warning은 다시 나오지 않을 수 있습니다.

**BehaviorScript에만 Yes를 눌러서는 부족합니다.** Script Node 승인이 없으면 이 Script Node가 포함된 Action Graph 전체가 비활성화됩니다. 화면에 저장된 `runEnabled=True`가 보여도 node가 실행 중이라는 뜻은 아닙니다.

**→ 정상 표시:** `ContactEventLatch`에 기본 Exec In/Exec Out과 bool output `runEnabled`가 있습니다.

`prepare_and_open(3)`으로 연 완성본에는 같은 코드가 **Inline Script**에 저장됩니다. 그 경우 Use Script File은 꺼진 상태가 정상입니다.

## 3-3. bool과 execution 순서 연결

먼저 On Playback Tick에서 세 Conveyor Belt의 On Step으로 직접 가던 선을 끊습니다. 아래처럼 Script Node를 경유시킵니다.

| 출발 node · port | 도착 node · port |
|---|---|
| On Playback Tick · Tick | `ContactEventLatch` · Exec In |
| `ContactEventLatch` · Exec Out | 세 Conveyor Belt · On Step |
| `ContactEventLatch` · `runEnabled` | `LabSelectSpeed` · Condition |
| `LabSelectSpeed` · Result | 세 Conveyor Belt · Velocity |
| On Playback Tick · Delta Seconds | 세 Conveyor Belt · Delta |

**→ 정상 표시:** 매 tick에 Script Node가 bool을 갱신한 다음 conveyor가 실행됩니다. `runEnabled`에는 선 하나만 연결하면 됩니다.

## 3-4. 코드에서 볼 부분

실제 코드는 `contact_event_latch.py`에 있습니다. 수업 중에는 다음 네 동작을 확인합니다.

| 시점 | Script Node가 하는 일 |
|---|---|
| 첫 실행 또는 node Reset의 `setup()` | 저장 상태를 `True`로 초기화하고 `ngv.tutorial.guard_contact` 구독 |
| Guard contact event 수신 | 저장 상태를 `False`로 변경 |
| 매 tick의 `compute()` | 저장 상태를 `db.outputs.runEnabled`로 출력하고 Exec Out 실행 |
| Timeline Stop | 저장 상태만 `True`로 복원; 다음 Play의 tick에서 출력에 반영 |

`setup()`은 매 Play마다 다시 구독하는 함수가 아닙니다. **Pause → Play는 정지 상태를 유지**하고, **Stop → Play에서 운전 상태로 돌아갑니다.**

**event가 없는 동안도 bool output은 필요합니다.** 그래서 Script Node는 contact 순간만 실행하지 않고 **매 tick** 실행합니다. 첫 tick에 `True`, contact 이후 tick에는 `False`를 출력합니다.

`runEnabled=False`가 되어도 **Exec Out은 매 tick 계속 나옵니다.** 그래야 Conveyor Belt node가 실행되어 정지 속도 `0.0`을 실제 surface velocity에 적용합니다.

## 3-5. 실행 확인

**처음 구성할 때 속도 설정:** **Stop** 상태에서 Lane01의 세 conveyor `Rollers`의 `Surface Velocity`와 `Surface Angular Velocity`를 모두 `(0, 0, 0)`으로 둡니다. 곡선 구간 `conveyor_belt_02`는 **Curved = True**, **Direction = `(0, 0, -38.197186)`**입니다. Play 중에는 graph가 surface velocity를 갱신합니다. 접촉 후에는 graph의 Velocity뿐 아니라 세 Rollers의 실제 surface velocity 두 값도 모두 0이어야 합니다.

1. **Stop** 상태에서 가운데 직선 conveyor 위의 **주황색 제품 box**를 확인합니다. 없으면 공통 준비의 `lab.add_demo_box()`를 실행합니다.
2. **Play**합니다. **→ 첫 tick의 `runEnabled = True`, Velocity = `1.0`. box가 conveyor를 따라 이동합니다.**
3. box가 Guard에 접촉합니다. **→ `runEnabled = False`, Velocity = `0.0`, box 정지.**
4. **Stop**하면 box가 시작 위치로 돌아옵니다. 다시 **Play**합니다. **→ 접촉 전에는 다시 `True`, `1.0`.**

## 문제 해결

| 증상 | 확인할 곳 |
|---|---|
| `runEnabled`가 없다는 오류 | Add Attribute에서 Output / bool / `runEnabled`를 정확히 만들었는지 확인 |
| Script Node 또는 graph 전체가 실행되지 않음 | 별도의 ScriptNode Warning에서 Yes를 눌렀는지 먼저 확인; 이어서 script 설정과 Tick → Exec In 확인 |
| 접촉 후에도 bool이 True | BehaviorScript와 Script Node의 두 실행 승인, Guard의 script 등록, event name 확인 |
| bool은 False이고 Velocity도 0인데 계속 움직임 | 곡선 Rollers의 잔류 Surface Velocity를 0으로 수정하고 위 속도 설정 확인 |
| 속도 적용이 한 frame씩 어긋나거나 불안정 | Tick → conveyor 직접 연결을 끊고 Script Node Exec Out만 On Step에 연결 |
| 새 simulation에서도 False 유지 | Pause → Play가 아니라 **Stop → Play**로 재시작 |

**기억할 것:** Script Node는 event를 받는 기능과 bool 상태를 유지하는 기능을 한 node에 모읍니다.
