"""Day2 오전: contact event로 conveyor를 제어하는 세 가지 예제."""
