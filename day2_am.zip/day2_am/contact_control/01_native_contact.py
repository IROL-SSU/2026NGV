"""준비된 tutorial scene에서 mode 1: 순수 Action Graph."""
import runpy
from pathlib import Path

lab = runpy.run_path(str(Path(__file__).with_name("tutorial.py")))
lab["apply_mode"](1)
