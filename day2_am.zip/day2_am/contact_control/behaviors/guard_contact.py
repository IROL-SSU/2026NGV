"""Guard prim에 붙이는 BehaviorScript. 한 번 contact하면 event를 한 번 보낸다."""
from collections import deque

import carb.events
import omni.kit.app
import omni.physx
from omni.behavior.scripting.core import BehaviorScript
from omni.physx.bindings import _physx
from pxr import PhysicsSchemaTools

EVENT_NAME = "ngv.tutorial.guard_contact"


class GuardContact(BehaviorScript):
    def on_init(self):
        self._contact_subscription = None
        self._pending = deque()
        self._sent = False
        self._bus = omni.kit.app.get_app().get_message_bus_event_stream()

    def on_play(self):
        # Pause -> Play에서는 정지 latch를 유지한다. Stop -> Play만 초기화한다.
        if self._contact_subscription is not None:
            return
        self._pending.clear()
        self._sent = False
        self._contact_subscription = (
            omni.physx.get_physx_simulation_interface()
            .subscribe_contact_report_events(self._on_contact)
        )

    def _on_contact(self, headers, contact_data):
        guard_path = str(self.prim_path)
        prim = self.usd_context.get_stage().GetPrimAtPath(self.prim_path)
        attr = prim.GetAttribute("ngv:tutorial:otherBodyPrefix")
        prefix = (attr.Get() or "").rstrip("/") if attr else ""
        for header in headers:
            if header.stage_id != self.usd_context.get_stage_id():
                continue
            if header.type != _physx.ContactEventType.CONTACT_FOUND:
                continue
            actors = [str(PhysicsSchemaTools.intToSdfPath(header.actor0)),
                      str(PhysicsSchemaTools.intToSdfPath(header.actor1))]
            if guard_path not in actors:
                continue
            other = actors[1] if actors[0] == guard_path else actors[0]
            # 빈 문자열이면 모든 접촉. 값이 있으면 그 prim 또는 하위 body만 허용.
            if prefix and other != prefix and not other.startswith(prefix + "/"):
                continue
            self._pending.append(other)

    def on_update(self, current_time, delta_time):
        # Physics callback에서는 검출만 하고, 다음 update에서 Kit event를 보낸다.
        if self._pending and not self._sent:
            other = self._pending.popleft()
            self._sent = True
            self._bus.push(
                carb.events.type_from_string(EVENT_NAME),
                payload={"guard": str(self.prim_path), "other": other, "contact": True},
            )
        self._pending.clear()

    def on_stop(self):
        # 구독 객체를 보관해야 callback이 유지된다. None으로 해제한다.
        self._contact_subscription = None
        self._pending.clear()
        self._sent = False

    def on_destroy(self):
        self.on_stop()
