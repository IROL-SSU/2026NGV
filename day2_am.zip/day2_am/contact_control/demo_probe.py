"""Stop 상태에서 실행한 뒤 Play: Guard 앞 검증용 sphere가 이동한다."""
import runpy
from pathlib import Path

lab = runpy.run_path(str(Path(__file__).with_name("tutorial.py")))
lab["add_demo_probe"]()
