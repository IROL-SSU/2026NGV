"""Stop 상태의 tutorial graph에 FloatDrag UI와 RampSpeed를 연결한다."""
import asyncio
from pathlib import Path
import omni.kit.app
import omni.timeline


async def connect_ui():
    if not omni.timeline.get_timeline_interface().is_stopped():
        raise RuntimeError('Stop timeline before connecting RampSpeed.')
    app = omni.kit.app.get_app()
    manager = app.get_extension_manager()
    manager.add_path(str(Path(__file__).resolve().parents[1] / 'extensions'))
    for _ in range(3):
        await app.next_update_async()
    if not manager.set_extension_enabled_immediate('ngv.conveyor_control', True):
        raise RuntimeError('NGV Conveyor Control extension could not be enabled.')
    from ngv.conveyor_control import attach_ramp
    print('NGV_CONVEYOR_UI_CONNECTED', attach_ramp())


conveyor_ui_task = asyncio.ensure_future(connect_ui())
