"""Isaac Sim 6.2 Script Editor에서 실행하는 contact tutorial setup.

prepare_and_open(1)로 별도 scene을 만든 뒤 apply_mode(2/3)로 비교한다.
원본 day2_completed.usda와 그 asset에는 쓰지 않는다.
"""
from pathlib import Path
import hashlib
import math
import os
import tempfile

HERE = Path(__file__).resolve().parent
GRAPH = "/World/Graphs/Lane01ActionGraph"
GUARD = "/World/Lane01/Guard"
EVENT_NAME = "ngv.tutorial.guard_contact"
OWNER = "ngv.contact_control.v1"
OWNER_KEY = "ngv:contactControlOwner"
BELTS = ("conveyor_belt", "conveyor_belt_01", "conveyor_belt_02")
TARGETS = ("/World/Lane01/ConveyorBelt_A05/Rollers",
           "/World/Lane01/ConveyorBelt_A05_01/Rollers",
           "/World/Lane01/ConveyorBelt_A02/Rollers")
CURVE_RADIUS = 1.5
CURVE_DEGREES_PER_METER = 180.0 / (math.pi * CURVE_RADIUS)
COMMON_NODES = (
    ("LabRunSpeed", "omni.graph.nodes.ConstantFloat"),
    ("LabStopSpeed", "omni.graph.nodes.ConstantFloat"),
    ("LabSelectSpeed", "omni.graph.nodes.SelectIf"),
)
VARIABLE_NODES = (
    ("StopOnContact", "omni.graph.core.WriteVariable"),
    ("OnSimulationStart", "omni.graph.action.OnStageEvent"),
    ("RunOnStart", "omni.graph.core.WriteVariable"),
    ("AutoRunEnabled", "omni.graph.core.ReadVariable"),
)
MODE_NODES = {
    1: VARIABLE_NODES + (("OnGuardContact", "omni.physx.graph.OnContactEventBasic"),),
    2: VARIABLE_NODES + (("OnBehaviorContact", "omni.graph.action.OnMessageBusEvent"),),
    3: (("ContactEventLatch", "omni.graph.scriptnode.ScriptNode"),),
}


def _path(relative):
    return GRAPH + "/" + relative


def _mode(mode):
    if isinstance(mode, bool) or mode not in MODE_NODES:
        raise ValueError("mode는 1, 2, 3 중 하나입니다.")
    return int(mode)


def _require_base(stage):
    from pxr import Sdf
    for name, target in zip(BELTS, TARGETS):
        prim = stage.GetPrimAtPath(_path(name))
        if not prim or prim.GetAttribute("node:type").Get() != "isaacsim.asset.gen.conveyor.IsaacConveyor":
            raise ValueError("원본 Lane01 conveyor node를 찾지 못했습니다: " + name)
        if prim.GetRelationship("inputs:conveyorPrim").GetTargets() != [Sdf.Path(target)]:
            raise ValueError("원본 conveyor target과 다릅니다: " + name)
    if not stage.GetPrimAtPath(GUARD) or not stage.GetPrimAtPath(_path("on_playback_tick")):
        raise ValueError("Guard와 on_playback_tick이 있는 day2_completed scene이 필요합니다.")


def prepare_scene(mode=1, source=None, output_dir=None):
    """원본 disk 사본을 sublayer로 쓰는 결과 scene 경로를 반환한다. 현재 UI는 그대로 둔다."""
    from pxr import Sdf, Usd, UsdGeom, UsdUtils
    mode = _mode(mode)
    source = Path(source).resolve() if source else HERE.parent.parent / "researcher_examples/scenes/day2_completed.usda"
    if not source.is_file():
        raise FileNotFoundError("researcher_examples와 day2_am을 같은 NGV_lab 폴더에 둡니다: " + str(source))
    results = Path(output_dir).resolve() if output_dir else HERE.parent / "results"
    results.mkdir(parents=True, exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix=f"contact_control_mode{mode}_", dir=str(results)))
    # 같은 원본이 UI에 열려 있으면 Sdf.Layer cache에는 저장 전 수정도 섞인다.
    # disk bytes만 새 layer에 읽어 원본의 현재 UI 상태와 분리한다.
    source_bytes = source.read_bytes()
    snapshot = Sdf.Layer.CreateNew(str(folder / "source_snapshot.usda"))
    if not snapshot.ImportFromString(source_bytes.decode("utf-8-sig")):
        raise ValueError("원본 USDA를 disk에서 읽지 못했습니다: " + str(source))

    def reanchor(asset_path):
        if not asset_path or "://" in asset_path or Path(asset_path).is_absolute():
            return asset_path
        absolute = (source.parent / asset_path).resolve()
        return os.path.relpath(absolute, folder).replace(os.sep, "/")

    UsdUtils.ModifyAssetPaths(snapshot, reanchor)
    snapshot.Save()
    original = Usd.Stage.Open(snapshot, Usd.Stage.LoadNone)
    if original is None:
        raise ValueError("원본 USD scene을 열지 못했습니다.")
    _require_base(original)
    # 다른 실습의 answer 파일을 원본으로 사용하면 node를 덮어쓰지 않고 중단한다.
    reserved = {name for name, _ in COMMON_NODES + sum(MODE_NODES.values(), ())}
    if any(original.GetPrimAtPath(_path(name)) for name in reserved):
        raise ValueError("수정하지 않은 researcher_examples/scenes/day2_completed.usda가 필요합니다.")
    destination = folder / f"mode{mode}.usda"
    layer = Sdf.Layer.CreateNew(str(destination))
    layer.subLayerPaths = ["source_snapshot.usda"]
    layer.customLayerData = {"ngv_contact_control": OWNER,
                            "source_scene": str(source).replace("\\", "/"),
                            "source_sha256": hashlib.sha256(source_bytes).hexdigest()}
    data = dict(layer.customLayerData)
    camera = original.GetRootLayer().customLayerData.get("cameraSettings")
    if camera is not None:
        data["cameraSettings"] = camera
    layer.customLayerData = data
    stage = Usd.Stage.Open(layer, Usd.Stage.LoadNone)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.GetStageUpAxis(original))
    UsdGeom.SetStageMetersPerUnit(stage, UsdGeom.GetStageMetersPerUnit(original))
    stage.SetStartTimeCode(original.GetStartTimeCode())
    stage.SetEndTimeCode(original.GetEndTimeCode())
    stage.SetTimeCodesPerSecond(original.GetTimeCodesPerSecond())
    stage.SetFramesPerSecond(original.GetFramesPerSecond())
    if original.GetDefaultPrim():
        stage.SetDefaultPrim(stage.GetPrimAtPath(original.GetDefaultPrim().GetPath()))
    _configure_conveyor_surfaces(stage)
    layer.Save()
    print("CONTACT_SCENE_CREATED:", destination)
    return destination


def _enable_extensions(mode):
    import omni.kit.app
    manager = omni.kit.app.get_app().get_extension_manager()
    names = ["omni.physx.graph", "omni.graph.nodes", "omni.graph.nodes_core",
             "omni.graph.action_nodes", "omni.graph.action_nodes_core"]
    if mode in (2, 3):
        names += ["omni.behavior.scripting.core", "omni.behavior.scripting.ui"]
    if mode == 3:
        names.append("omni.graph.scriptnode")
    for name in names:
        if not manager.is_extension_enabled(name):
            manager.set_extension_enabled_immediate(name, True)
        if not manager.is_extension_enabled(name):
            raise RuntimeError("필요한 extension을 활성화하지 못했습니다: " + name)


async def prepare_and_open(mode=1, source=None, output_dir=None):
    """Script Editor: asyncio.ensure_future(lab.prepare_and_open(1))."""
    import omni.kit.app
    import omni.timeline
    import omni.usd
    mode = _mode(mode)
    if not omni.timeline.get_timeline_interface().is_stopped():
        raise RuntimeError("먼저 Timeline의 Stop을 누릅니다.")
    _enable_extensions(mode)
    destination = prepare_scene(mode, source, output_dir)
    result = await omni.usd.get_context().open_stage_async(str(destination))
    if isinstance(result, tuple) and not result[0]:
        raise RuntimeError("결과 scene을 열지 못했습니다: " + str(result))
    for _ in range(3):
        await omni.kit.app.get_app().next_update_async()
    apply_mode(mode)
    add_demo_box()
    omni.usd.get_context().get_stage().GetRootLayer().Save()
    print("CONTACT_TUTORIAL_READY:", destination)
    return destination


async def prepare_starter(source=None, output_dir=None):
    """수동 실습용: 원본 graph만 있는 별도 scene을 열고 control node는 추가하지 않는다."""
    import omni.kit.app
    import omni.timeline
    import omni.usd
    if not omni.timeline.get_timeline_interface().is_stopped():
        raise RuntimeError("먼저 Timeline의 Stop을 누릅니다.")
    _enable_extensions(1)
    destination = prepare_scene(1, source, output_dir)
    result = await omni.usd.get_context().open_stage_async(str(destination))
    if isinstance(result, tuple) and not result[0]:
        raise RuntimeError("결과 scene을 열지 못했습니다: " + str(result))
    await omni.kit.app.get_app().next_update_async()
    add_demo_box()
    omni.usd.get_context().get_stage().GetRootLayer().Save()
    print("CONTACT_STARTER_READY:", destination)
    return destination


def _active_stage(stopped=True):
    import omni.timeline
    import omni.usd
    stage = omni.usd.get_context().get_stage()
    if not stage or stage.GetRootLayer().customLayerData.get("ngv_contact_control") != OWNER:
        raise ValueError("먼저 prepare_and_open(1)로 별도 tutorial scene을 만듭니다.")
    if stopped and not omni.timeline.get_timeline_interface().is_stopped():
        raise ValueError("Graph 구조를 바꾸기 전에 Timeline Stop을 누릅니다.")
    _require_base(stage)
    return stage


def _configure_conveyor_surfaces(stage):
    """이 scene의 각 구간이 사용하는 surface velocity만 남긴다."""
    from pxr import Gf, Sdf, Usd
    _require_base(stage)
    with Usd.EditContext(stage, stage.GetRootLayer()):
        for target in TARGETS:
            prim = stage.GetPrimAtPath(target)
            for name in ('physxSurfaceVelocity:surfaceVelocity', 'physxSurfaceVelocity:surfaceAngularVelocity'):
                attr = prim.GetAttribute(name)
                if not attr:
                    attr = prim.CreateAttribute(name, Sdf.ValueTypeNames.Vector3f, False)
                attr.Set(Gf.Vec3f(0))
        curve = stage.GetPrimAtPath(_path('conveyor_belt_02'))
        curve.CreateAttribute('inputs:curved', Sdf.ValueTypeNames.Bool, False).Set(True)
        # IsaacConveyor multiplies Direction by Velocity without normalization.
        # Curved surface velocity uses degrees/s; keep the shared scalar in m/s.
        curve.CreateAttribute('inputs:direction', Sdf.ValueTypeNames.Float3, False).Set(
            Gf.Vec3f(0, 0, -CURVE_DEGREES_PER_METER))


def repair_conveyor_drive():
    """Stop 상태에서 곡선 구간의 잔류 linear drive와 회전축을 수정한다."""
    _configure_conveyor_surfaces(_active_stage())
    print('CONVEYOR_DRIVE_READY: no residual surface velocity; curve calibrated for 1.5 m radius.')


def _wire(stage, source, destination):
    """해당 입력의 기존 연결을 정확히 하나로 교체한다. 사전 검증은 apply_mode에서 한다."""
    import omni.graph.core as og
    from pxr import Sdf
    src, dst = _path(source), _path(destination)
    attr = stage.GetAttributeAtPath(dst)
    if attr.GetConnections() == [Sdf.Path(src)]:
        return
    for previous in attr.GetConnections():
        og.Controller.disconnect(str(previous), dst)
    og.Controller.connect(src, dst)


def _cleanup_script_node(node):
    """6.2 ScriptNode의 연결 변경 후 `_db=None`인 경우도 구독을 정상 해제한다."""
    import omni.graph.core as og
    from omni.graph.scriptnode.ogn.OgnScriptNodeDatabase import OgnScriptNodeDatabase
    from omni.graph.scriptnode.ogn.python.nodes.OgnScriptNode import OgnScriptNode
    if not og.Controller.get(node.get_attribute("state:omni_initialized")):
        return
    # SDK abi.compute와 동일한 cache 복구. constructor는 기존 internal_state를 보존한다.
    data = OgnScriptNodeDatabase.PER_NODE_DATA[node.node_id()]
    if data.get("_db") is None:
        data["_db"] = OgnScriptNodeDatabase(node)
    OgnScriptNode.try_cleanup(node)


def apply_mode(mode):
    """현재 tutorial scene의 mode만 교체한다. 값은 보존하며 저장은 File > Save로 한다."""
    import omni.graph.core as og
    from pxr import Gf, Sdf, Usd, UsdPhysics, PhysxSchema
    mode = _mode(mode)
    stage = _active_stage()
    if stage.GetPrimAtPath(_path("RampSpeed")):
        raise ValueError("먼저 conveyor UI의 Remove Ramp를 누른 뒤 mode를 바꿉니다.")
    all_nodes = dict(COMMON_NODES + sum(MODE_NODES.values(), ()))
    for name, node_type in all_nodes.items():
        prim = stage.GetPrimAtPath(_path(name))
        if prim and (prim.GetCustomDataByKey(OWNER_KEY) != OWNER or
                     prim.GetAttribute("node:type").Get() != node_type):
            raise ValueError("동명 node를 보호하기 위해 중단했습니다: " + name)
    # 원래 Tick과 이 helper의 node 이외 연결은 자동으로 끊지 않는다.
    allowed = set(all_nodes) | {"on_playback_tick"}
    for name in BELTS:
        for port in ("inputs:velocity", "inputs:onStep"):
            for connection in stage.GetPrimAtPath(_path(name)).GetAttribute(port).GetConnections():
                if connection.GetPrimPath().GetParentPath() != Sdf.Path(GRAPH) or connection.GetPrimPath().name not in allowed:
                    raise ValueError("사용자 연결을 보호하기 위해 중단했습니다: " + str(connection))
    guard = stage.GetPrimAtPath(GUARD)
    scripts_attr = guard.GetAttribute("omni:scripting:scripts")
    existing_scripts = scripts_attr.Get() or [] if scripts_attr else []
    behavior_path = (HERE / "behaviors/guard_contact.py").as_posix()
    for asset in existing_scripts:
        if Path(asset.resolvedPath or asset.path).resolve() != Path(behavior_path):
            raise ValueError("Guard에 다른 BehaviorScript가 있습니다. 새 tutorial scene에서 시작합니다.")
    _enable_extensions(mode)
    keys = og.Controller.Keys
    with Usd.EditContext(stage, stage.GetRootLayer()):
        # ScriptNode의 Reset/삭제 전에 callback 구독을 먼저 해제한다.
        if stage.GetPrimAtPath(_path("ContactEventLatch")):
            _cleanup_script_node(og.Controller.node(_path("ContactEventLatch")))
        # mode 변경 전의 실행선은 원래 Tick으로 복구한 후 소유 node만 제거한다.
        for name in BELTS:
            _wire(stage, "on_playback_tick.outputs:tick", name + ".inputs:onStep")
        wanted = dict(COMMON_NODES + MODE_NODES[mode])
        # DELETE_NODES는 graph-relative 이름, SET_VALUES/CONNECT는 absolute port path.
        obsolete = [name for name in all_nodes if name not in wanted and stage.GetPrimAtPath(_path(name))]
        if obsolete:
            og.Controller.edit(GRAPH, {keys.DELETE_NODES: obsolete})
        new_nodes = [(name, kind) for name, kind in wanted.items() if not stage.GetPrimAtPath(_path(name))]
        if new_nodes:
            og.Controller.edit(GRAPH, {keys.CREATE_NODES: new_nodes})
        for name in wanted:
            stage.GetPrimAtPath(_path(name)).SetCustomDataByKey(OWNER_KEY, OWNER)
        values = []
        newly_created = {name for name, _ in new_nodes}
        for name, default in (("LabRunSpeed", 1.0), ("LabStopSpeed", 0.0)):
            if name in newly_created:
                values.append((_path(name + ".inputs:value"), default))
        connections = [("LabRunSpeed.inputs:value", "LabSelectSpeed.inputs:ifTrue"),
                       ("LabStopSpeed.inputs:value", "LabSelectSpeed.inputs:ifFalse")]
        PhysxSchema.PhysxContactReportAPI.Apply(guard).CreateThresholdAttr(0.0)
        if not guard.HasAPI(UsdPhysics.CollisionAPI) or not guard.HasAPI(UsdPhysics.RigidBodyAPI):
            raise ValueError("Guard에는 CollisionAPI와 RigidBodyAPI가 필요합니다.")
        _configure_conveyor_surfaces(stage)
        if mode in (1, 2):
            variable = stage.GetPrimAtPath(GRAPH).GetAttribute("graph:variable:LabRunEnabled")
            if not variable:
                og.Controller.edit(GRAPH, {keys.CREATE_VARIABLES: [("LabRunEnabled", og.Type(og.BaseDataType.BOOL))]})
            stage.GetPrimAtPath(GRAPH).GetAttribute("graph:variable:LabRunEnabled").Set(True)
            # The graph-variable Property UI uses inputs:graph to list variables.
            # An empty target causes it to clear inputs:variableName on selection.
            for name in ('RunOnStart', 'StopOnContact', 'AutoRunEnabled'):
                stage.GetPrimAtPath(_path(name)).CreateRelationship('inputs:graph', True).SetTargets([Sdf.Path(GRAPH)])
            values += [(_path("StopOnContact.inputs:variableName"), "LabRunEnabled"),
                       (_path("StopOnContact.inputs:value"), {"type": "bool", "value": False}),
                       (_path("OnSimulationStart.inputs:eventName"), "Simulation Start Play"),
                       (_path("OnSimulationStart.inputs:onlyPlayback"), True),
                       (_path("RunOnStart.inputs:variableName"), "LabRunEnabled"),
                       (_path("RunOnStart.inputs:value"), {"type": "bool", "value": True}),
                       (_path("AutoRunEnabled.inputs:variableName"), "LabRunEnabled")]
            connections += [("OnSimulationStart.outputs:execOut", "RunOnStart.inputs:execIn"),
                            ("AutoRunEnabled.outputs:value", "LabSelectSpeed.inputs:condition")]
            if mode == 1:
                values.append((_path("OnGuardContact.inputs:bodyPaths"), [GUARD]))
                connections.append(("OnGuardContact.outputs:foundExecOut", "StopOnContact.inputs:execIn"))
            else:
                values += [(_path("OnBehaviorContact.inputs:eventName"), EVENT_NAME),
                           (_path("OnBehaviorContact.inputs:onlyPlayback"), True)]
                connections.append(("OnBehaviorContact.outputs:execOut", "StopOnContact.inputs:execIn"))
        else:
            node = og.Controller.node(_path("ContactEventLatch"))
            if not node.get_attribute_exists("outputs:runEnabled"):
                node.create_attribute("outputs:runEnabled", og.Type(og.BaseDataType.BOOL),
                                      og.AttributePortType.ATTRIBUTE_PORT_TYPE_OUTPUT)
            values += [(_path("ContactEventLatch.inputs:usePath"), False),
                       (_path("ContactEventLatch.inputs:script"), (HERE / "nodes/contact_event_latch.py").read_text(encoding="utf-8")),
                       (_path("ContactEventLatch.state:omni_initialized"), False),
                       (_path("ContactEventLatch.outputs:runEnabled"), True)]
            connections += [("on_playback_tick.outputs:tick", "ContactEventLatch.inputs:execIn"),
                            ("ContactEventLatch.outputs:runEnabled", "LabSelectSpeed.inputs:condition")]
            connections += [("ContactEventLatch.outputs:execOut", name + ".inputs:onStep") for name in BELTS]
        if values:
            og.Controller.edit(GRAPH, {keys.SET_VALUES: values})
        connections += [("LabSelectSpeed.outputs:result", name + ".inputs:velocity") for name in BELTS]
        for src, dst in connections:
            _wire(stage, src, dst)
        if mode in (2, 3):
            import OmniScriptingSchemaTools
            OmniScriptingSchemaTools.applyOmniScriptingAPI(stage, Sdf.Path(GUARD))
            guard.CreateAttribute("omni:scripting:scripts", Sdf.ValueTypeNames.AssetArray).Set([Sdf.AssetPath(behavior_path)])
            if not guard.GetAttribute("ngv:tutorial:otherBodyPrefix"):
                guard.CreateAttribute("ngv:tutorial:otherBodyPrefix", Sdf.ValueTypeNames.String).Set("")
        elif scripts_attr:
            scripts_attr.Set([])
        graph_prim = stage.GetPrimAtPath(GRAPH)
        graph_prim.SetCustomDataByKey("ngv:contactControlMode", mode)
        positions = {"OnSimulationStart": (-650, -300), "RunOnStart": (-300, -300),
                     "OnGuardContact": (-650, -40), "OnBehaviorContact": (-650, -40),
                     "StopOnContact": (-300, -40), "AutoRunEnabled": (30, -300),
                     "ContactEventLatch": (-300, -250), "LabRunSpeed": (30, -130),
                     "LabStopSpeed": (30, 20), "LabSelectSpeed": (350, -200),
                     "on_playback_tick": (-650, 220), "conveyor_belt": (50, 350),
                     "conveyor_belt_01": (400, 350), "conveyor_belt_02": (750, 350)}
        for name, pos in positions.items():
            prim = stage.GetPrimAtPath(_path(name))
            if prim:
                prim.CreateAttribute("ui:nodegraph:node:pos", Sdf.ValueTypeNames.Float2, False).Set(Gf.Vec2f(*pos))
    print(f"MODE_{mode}_READY: contact 전 운전, 첫 contact 후 정지, Stop -> Play로 재시작")
    print("Graph:", GRAPH, "| 변경 저장: File > Save")
    return inspect()


def inspect():
    """현재 mode와 실제 OGN 값을 읽기만 한다."""
    import omni.graph.core as og
    stage = _active_stage(stopped=False)
    mode = stage.GetPrimAtPath(GRAPH).GetCustomDataByKey("ngv:contactControlMode")
    run_port = "ContactEventLatch.outputs:runEnabled" if mode == 3 else "AutoRunEnabled.outputs:value"
    ports = [run_port, "LabRunSpeed.inputs:value", "LabStopSpeed.inputs:value", "LabSelectSpeed.outputs:result"]
    ports += [name + ".inputs:velocity" for name in BELTS]
    result = {"mode": mode, "scene": stage.GetRootLayer().identifier, "values": {}}
    for port in ports:
        attr = og.Controller.attribute(_path(port))
        result["values"][port] = attr.get() if attr.is_valid() else None
    print(result)
    return result


def add_demo_box():
    """주황색 제품 box를 보이는 직선 conveyor 위에 놓는다. 초기 속도는 0이다."""
    return _author_demo_box(_active_stage())


def _author_demo_box(stage):
    """준비된 stage의 제품 prim만 작성한다. graph와 다른 scene prim은 유지한다."""
    from pxr import Gf, Usd, UsdGeom, UsdPhysics
    path = '/World/ContactTutorialBox'
    previous = stage.GetPrimAtPath(path)
    if previous and previous.GetCustomDataByKey(OWNER_KEY) != OWNER:
        raise ValueError('동명 prim을 보호하기 위해 중단했습니다: ' + path)
    with Usd.EditContext(stage, stage.GetRootLayer()):
        if previous:
            stage.RemovePrim(path)
        root = UsdGeom.Xform.Define(stage, path)
        root.AddTranslateOp().Set(Gf.Vec3d(-1.8, 2.0, 0.8753071))
        prim = root.GetPrim()
        prim.SetCustomDataByKey(OWNER_KEY, OWNER)
        prim.SetDisplayName('Tutorial Orange Box')
        cube = UsdGeom.Cube.Define(stage, path + '/Box')
        cube.CreateSizeAttr(1.0)
        cube.AddScaleOp().Set(Gf.Vec3f(0.30, 0.24, 0.20))
        cube.CreateDisplayColorAttr([Gf.Vec3f(1.0, 0.20, 0.02)])
        UsdPhysics.CollisionAPI.Apply(cube.GetPrim()).CreateCollisionEnabledAttr(True)
        body = UsdPhysics.RigidBodyAPI.Apply(prim)
        body.CreateRigidBodyEnabledAttr(True)
        body.CreateKinematicEnabledAttr(False)
        body.CreateVelocityAttr(Gf.Vec3f(0))
        body.CreateAngularVelocityAttr(Gf.Vec3f(0))
        UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(0.25)
    print('DEMO_BOX_READY: orange box on Lane01; Play moves it toward Guard.')
    return path


def remove_demo_box():
    """Stop 상태에서 이 실습의 제품 box만 제거한다."""
    from pxr import Usd
    stage = _active_stage()
    path = '/World/ContactTutorialBox'
    prim = stage.GetPrimAtPath(path)
    if prim:
        if prim.GetCustomDataByKey(OWNER_KEY) != OWNER:
            raise ValueError('동명 prim을 보호하기 위해 중단했습니다: ' + path)
        with Usd.EditContext(stage, stage.GetRootLayer()):
            stage.RemovePrim(path)
    return not bool(stage.GetPrimAtPath(path))


def add_demo_probe(distance=0.25):
    """Guard로 이동하는 검증용 sphere를 생성한다. conveyor 운반과 별개의 contact 확인용이다."""
    from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics, PhysxSchema
    distance = float(distance)
    if not math.isfinite(distance) or distance < 0.12:
        raise ValueError("distance는 0.12m 이상의 유한한 값입니다.")
    stage = _active_stage()
    path = "/World/ContactTutorialProbe"
    prim = stage.GetPrimAtPath(path)
    if prim and prim.GetCustomDataByKey(OWNER_KEY) != OWNER:
        raise ValueError("동명 prim을 보호하기 위해 중단했습니다: " + path)
    with Usd.EditContext(stage, stage.GetRootLayer()):
        if prim:
            stage.RemovePrim(path)
        sphere = UsdGeom.Sphere.Define(stage, path)
        sphere.CreateRadiusAttr(0.06)
        sphere.AddTranslateOp().Set(Gf.Vec3d(1.0, 0.35 - float(distance), 0.5))
        sphere.CreateDisplayColorAttr([Gf.Vec3f(1.0, 0.35, 0.05)])
        prim = sphere.GetPrim()
        prim.SetCustomDataByKey(OWNER_KEY, OWNER)
        UsdPhysics.CollisionAPI.Apply(prim)
        body = UsdPhysics.RigidBodyAPI.Apply(prim)
        body.CreateVelocityAttr(Gf.Vec3f(0, 0.8, 0))
        PhysxSchema.PhysxRigidBodyAPI.Apply(prim).CreateDisableGravityAttr(True)
    print(f"DEMO_PROBE_READY: 예상 contact 시간 약 {(float(distance) - 0.06) / 0.8:.2f}초")
    return path


def remove_demo_probe():
    """Stop 상태에서 이 실습이 만든 sphere만 제거한다."""
    from pxr import Usd
    stage = _active_stage()
    path = "/World/ContactTutorialProbe"
    prim = stage.GetPrimAtPath(path)
    if prim:
        if prim.GetCustomDataByKey(OWNER_KEY) != OWNER:
            raise ValueError("동명 prim을 보호하기 위해 중단했습니다: " + path)
        with Usd.EditContext(stage, stage.GetRootLayer()):
            stage.RemovePrim(path)
    return not bool(stage.GetPrimAtPath(path))
