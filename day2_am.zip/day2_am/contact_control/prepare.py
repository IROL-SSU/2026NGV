"""Script Editor에서 runpy.run_path(이 파일의 절대 경로)로 실행한다."""
import asyncio
import runpy
from pathlib import Path

lab = runpy.run_path(str(Path(__file__).with_name("tutorial.py")))
contact_tutorial_task = asyncio.ensure_future(lab["prepare_and_open"](1))
