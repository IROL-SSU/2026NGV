"""Script Node의 Inline Script. dynamic output: runEnabled(bool).

Tick -> 이 Script Node -> Conveyor의 실행 순서로 연결한다.
setup/cleanup은 Script Node가 호출한다. compute는 매 Tick 호출된다.
"""
import carb.events
import omni.kit.app
import omni.timeline

EVENT_NAME = "ngv.tutorial.guard_contact"
GUARD_PATH = "/World/Lane01/Guard"


def setup(db):
    state = db.per_instance_state
    # Reset 버튼으로 다시 setup될 때도 기존 구독이 남지 않게 한다.
    state.message_subscription = None
    state.timeline_subscription = None
    state.run_enabled = True

    def on_contact(event):
        if event.payload.get("guard", "") == GUARD_PATH:
            state.run_enabled = False

    def on_timeline(event):
        # Pause/Resume에는 latch를 유지하고 Stop에서만 다음 run을 준비한다.
        if event.type == int(omni.timeline.TimelineEventType.STOP):
            state.run_enabled = True

    bus = omni.kit.app.get_app().get_message_bus_event_stream()
    state.message_subscription = bus.create_subscription_to_pop_by_type(
        carb.events.type_from_string(EVENT_NAME), on_contact,
        name="NGV contact tutorial Script Node",
    )
    state.timeline_subscription = (
        omni.timeline.get_timeline_interface().get_timeline_event_stream()
        .create_subscription_to_pop(on_timeline, name="NGV contact tutorial reset")
    )
    db.outputs.runEnabled = True


def compute(db):
    db.outputs.runEnabled = db.per_instance_state.run_enabled
    return True


def cleanup(db):
    db.per_instance_state.message_subscription = None
    db.per_instance_state.timeline_subscription = None
