"""준비된 tutorial scene에서 mode 3: BehaviorScript -> Script Node."""
import runpy
from pathlib import Path

lab = runpy.run_path(str(Path(__file__).with_name("tutorial.py")))
lab["apply_mode"](3)
