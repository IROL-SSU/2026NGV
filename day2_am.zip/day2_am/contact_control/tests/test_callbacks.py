"""Isaac 없이 lifecycle/filter/latch를 검증. 실제 Physics/OGN 검증을 대체하지 않는다.

python -m unittest discover -s contact_control/tests -v
"""
import gc
import runpy
import sys
import types
import unittest
import weakref
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]


class Subscription:
    def __init__(self, callback, event_type=None):
        self.callback, self.event_type = callback, event_type


class Stream:
    def __init__(self):
        self.subscriptions = weakref.WeakSet()
        self.events = []

    def create_subscription_to_pop_by_type(self, kind, callback, **kwargs):
        sub = Subscription(callback, kind)
        self.subscriptions.add(sub)
        return sub

    def create_subscription_to_pop(self, callback, **kwargs):
        return self.create_subscription_to_pop_by_type(None, callback)

    def push(self, kind, payload):
        self.events.append((kind, payload))
        self.dispatch(kind, payload)

    def dispatch(self, kind, payload=None):
        event = types.SimpleNamespace(type=kind, payload=payload or {})
        for sub in list(self.subscriptions):
            if sub.event_type is None or sub.event_type == kind:
                sub.callback(event)


class CallbackTests(unittest.TestCase):
    def setUp(self):
        self.bus, self.timeline_stream, self.physics_stream = Stream(), Stream(), Stream()
        self.prefix = ""
        attr = types.SimpleNamespace(Get=lambda: self.prefix)
        prim = types.SimpleNamespace(GetAttribute=lambda key: attr)
        stage = types.SimpleNamespace(GetPrimAtPath=lambda path: prim)
        context = types.SimpleNamespace(get_stage=lambda: stage, get_stage_id=lambda: 7)
        timeline = types.SimpleNamespace(get_timeline_event_stream=lambda: self.timeline_stream)
        app = types.SimpleNamespace(get_message_bus_event_stream=lambda: self.bus)
        physics = types.SimpleNamespace(subscribe_contact_report_events=lambda cb: self.physics_stream.create_subscription_to_pop(cb))
        behavior = type("BehaviorScript", (), {"prim_path": "/World/Lane01/Guard", "usd_context": context})
        names = ["carb", "carb.events", "omni", "omni.kit", "omni.kit.app", "omni.timeline",
                 "omni.physx", "omni.physx.bindings", "omni.physx.bindings._physx",
                 "omni.behavior", "omni.behavior.scripting", "omni.behavior.scripting.core", "pxr"]
        self.modules = {name: types.ModuleType(name) for name in names}
        for name, module in self.modules.items():
            if "." in name:
                parent, attr_name = name.rsplit(".", 1)
                setattr(self.modules[parent], attr_name, module)
        self.modules["carb.events"].type_from_string = lambda name: name
        self.modules["omni.kit.app"].get_app = lambda: app
        self.modules["omni.timeline"].get_timeline_interface = lambda: timeline
        self.modules["omni.timeline"].TimelineEventType = types.SimpleNamespace(STOP=0, PLAY=1, PAUSE=2)
        self.modules["omni.physx"].get_physx_simulation_interface = lambda: physics
        self.modules["omni.physx.bindings._physx"].ContactEventType = types.SimpleNamespace(CONTACT_FOUND=1, CONTACT_LOST=2)
        self.modules["omni.behavior.scripting.core"].BehaviorScript = behavior
        self.modules["pxr"].PhysicsSchemaTools = types.SimpleNamespace(intToSdfPath=lambda value: value)
        self.patcher = patch.dict(sys.modules, self.modules)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()

    def behavior(self):
        cls = runpy.run_path(str(HERE / "behaviors/guard_contact.py"))["GuardContact"]
        instance = cls()
        instance.on_init()
        return instance

    def header(self, actor0="/World/Lane01/Guard", actor1="/World/Product", kind=1, stage_id=7):
        return types.SimpleNamespace(actor0=actor0, actor1=actor1, type=kind, stage_id=stage_id)

    def test_behavior_filters_and_emits_once_per_stop_play(self):
        behavior = self.behavior()
        behavior.on_play()
        first = behavior._contact_subscription
        behavior.on_play()  # Pause/Play의 중복 구독 방지.
        self.assertIs(first, behavior._contact_subscription)
        behavior._on_contact([self.header(stage_id=8), self.header(kind=2),
                              self.header(actor0="/World/Other")], [])
        behavior.on_update(0, 0.01)
        self.assertEqual(self.bus.events, [])
        self.prefix = "/World/Product"
        behavior._on_contact([self.header(actor1="/World/ProductWrong"),
                              self.header(actor0="/World/Product/Body", actor1="/World/Lane01/Guard")], [])
        behavior.on_update(0, 0.01)
        self.assertEqual(self.bus.events, [("ngv.tutorial.guard_contact",
                         {"guard": "/World/Lane01/Guard", "other": "/World/Product/Body", "contact": True})])
        behavior._on_contact([self.header()], [])
        behavior.on_update(0, 0.01)
        self.assertEqual(len(self.bus.events), 1)
        behavior.on_stop()
        self.assertIsNone(behavior._contact_subscription)
        behavior.on_play()
        behavior._on_contact([self.header()], [])
        behavior.on_update(0, 0.01)
        self.assertEqual(len(self.bus.events), 2)
        behavior.on_destroy()
        self.assertIsNone(behavior._contact_subscription)

    def test_script_node_latches_and_preserves_pause_then_resets_stop(self):
        code = runpy.run_path(str(HERE / "nodes/contact_event_latch.py"))
        db = types.SimpleNamespace(per_instance_state=types.SimpleNamespace(), outputs=types.SimpleNamespace())
        code["setup"](db)
        code["compute"](db)
        self.assertTrue(db.outputs.runEnabled)
        self.bus.push("ngv.tutorial.guard_contact", {"guard": "/World/AnotherGuard"})
        code["compute"](db)
        self.assertTrue(db.outputs.runEnabled)
        self.bus.push("ngv.tutorial.guard_contact", {"guard": "/World/Lane01/Guard"})
        code["compute"](db)
        self.assertFalse(db.outputs.runEnabled)
        self.timeline_stream.dispatch(2)
        self.timeline_stream.dispatch(1)
        code["compute"](db)
        self.assertFalse(db.outputs.runEnabled)
        self.timeline_stream.dispatch(0)
        code["compute"](db)
        self.assertTrue(db.outputs.runEnabled)
        code["cleanup"](db)
        gc.collect()
        self.assertEqual(len(self.bus.subscriptions), 0)
        self.assertEqual(len(self.timeline_stream.subscriptions), 0)
        code["setup"](db)
        code["setup"](db)
        gc.collect()
        self.assertEqual(len(self.bus.subscriptions), 1)
        self.assertEqual(len(self.timeline_stream.subscriptions), 1)
        code["cleanup"](db)


if __name__ == "__main__":
    unittest.main()
