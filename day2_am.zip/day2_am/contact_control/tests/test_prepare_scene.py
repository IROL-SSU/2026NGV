"""USD regression: 열린 source의 저장 전 수정과 disk 사본을 분리하고 상대 asset을 보존."""
import runpy
import tempfile
import unittest
from pathlib import Path

from pxr import Sdf, Usd

LAB = runpy.run_path(str(Path(__file__).resolve().parents[1] / "tutorial.py"))


class PrepareSceneTests(unittest.TestCase):
    def test_disk_snapshot_ignores_dirty_layer_and_reanchors_assets(self):
        with tempfile.TemporaryDirectory(prefix="ngv_contact_usd_test_", dir=Path(__file__).parent) as directory:
            root = Path(directory)
            (root / "assets").mkdir()
            (root / "scenes").mkdir()
            base_path = root / "assets/base.usda"
            base = Usd.Stage.CreateNew(str(base_path))
            base.DefinePrim(LAB["GUARD"])
            for target in LAB["TARGETS"]:
                base.DefinePrim(target)
            base.GetRootLayer().Save()
            source_path = root / "scenes/day2_completed.usda"
            source = Usd.Stage.CreateNew(str(source_path))
            source.GetRootLayer().subLayerPaths = ["../assets/base.usda"]
            graph = LAB["GRAPH"]
            source.DefinePrim(graph + "/on_playback_tick")
            for name, target in zip(LAB["BELTS"], LAB["TARGETS"]):
                node = source.DefinePrim(graph + "/" + name)
                node.CreateAttribute("node:type", Sdf.ValueTypeNames.Token).Set("isaacsim.asset.gen.conveyor.IsaacConveyor")
                node.CreateRelationship("inputs:conveyorPrim").SetTargets([Sdf.Path(target)])
            source.GetRootLayer().Save()
            disk_before = source_path.read_bytes()
            # 실제 오류 재현: 같은 identifier의 cached layer에 저장 전 Lab node가 존재.
            source.DefinePrim(graph + "/LabRunSpeed")
            result = LAB["prepare_scene"](1, source_path, root / "results")
            output = Usd.Stage.Open(str(result))
            self.assertTrue(output.GetPrimAtPath(LAB["GUARD"]))
            self.assertFalse(output.GetPrimAtPath(graph + "/LabRunSpeed"))
            self.assertTrue(source.GetPrimAtPath(graph + "/LabRunSpeed"))
            self.assertEqual(source_path.read_bytes(), disk_before)
            snapshot = Sdf.Layer.FindOrOpen(str(result.parent / "source_snapshot.usda"))
            anchored = (result.parent / snapshot.subLayerPaths[0]).resolve()
            self.assertEqual(anchored, base_path.resolve())
            self.assertEqual(output.GetRootLayer().customLayerData["ngv_contact_control"], LAB["OWNER"])
            # USD handle을 닫아 Windows에서 임시 directory를 정리할 수 있게 한다.
            output = snapshot = source = base = None


if __name__ == "__main__":
    unittest.main()
