"""ScriptNode SDK cache가 연결 변경으로 invalidation된 경우의 회귀 test."""
import runpy
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

LAB = runpy.run_path(str(Path(__file__).resolve().parents[1] / "tutorial.py"))


class CleanupTests(unittest.TestCase):
    def test_missing_db_is_rebuilt_without_losing_state_before_cleanup(self):
        initialized = types.SimpleNamespace(value=True)
        state = types.SimpleNamespace(subscription=object())
        node = types.SimpleNamespace(node_id=lambda: 10, get_attribute=lambda name: initialized)

        class Database:
            PER_NODE_DATA = {10: {"_db": None, "internal_state": state}}
            builds = 0

            def __init__(self, node):
                Database.builds += 1
                self.state = self.PER_NODE_DATA[node.node_id()]["internal_state"]

        def sdk_cleanup(target):
            db = Database.PER_NODE_DATA[target.node_id()]["_db"]
            self.assertIs(db.state, state)
            db.state.subscription = None
            initialized.value = False

        names = ["omni", "omni.graph", "omni.graph.core", "omni.graph.scriptnode",
                 "omni.graph.scriptnode.ogn", "omni.graph.scriptnode.ogn.OgnScriptNodeDatabase",
                 "omni.graph.scriptnode.ogn.python", "omni.graph.scriptnode.ogn.python.nodes",
                 "omni.graph.scriptnode.ogn.python.nodes.OgnScriptNode"]
        modules = {name: types.ModuleType(name) for name in names}
        for name, module in modules.items():
            if "." in name:
                parent, attr = name.rsplit(".", 1)
                setattr(modules[parent], attr, module)
        modules["omni.graph.core"].Controller = types.SimpleNamespace(get=lambda attr: attr.value)
        modules["omni.graph.scriptnode.ogn.OgnScriptNodeDatabase"].OgnScriptNodeDatabase = Database
        modules["omni.graph.scriptnode.ogn.python.nodes.OgnScriptNode"].OgnScriptNode = types.SimpleNamespace(try_cleanup=sdk_cleanup)
        with patch.dict(sys.modules, modules):
            LAB["_cleanup_script_node"](node)
            LAB["_cleanup_script_node"](node)  # 이미 해제한 node는 다시 setup/cleanup하지 않는다.
        self.assertEqual(Database.builds, 1)
        self.assertIsNone(state.subscription)
        self.assertFalse(initialized.value)


if __name__ == "__main__":
    unittest.main()
