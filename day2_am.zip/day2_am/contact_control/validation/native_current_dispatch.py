exec(compile(open('C:/Users/dhlee/claude/hundong/tmp_isaac_contact/native_live_entry.py', encoding='utf-8').read(), 'native_live_entry.py', 'exec'))
