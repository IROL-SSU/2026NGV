"""실행 중에도 현재 bool과 세 conveyor 속도를 출력한다."""
import runpy
from pathlib import Path

lab = runpy.run_path(str(Path(__file__).with_name("tutorial.py")))
lab["inspect"]()
