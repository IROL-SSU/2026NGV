# Changelog

## [1.0.1] - 2025-01-21
### Changed
- Update extension description and add extension specific test settings


## [0.1.0] - 2026-10-20

### Added

- Initial version of NGV Process UI Extension
