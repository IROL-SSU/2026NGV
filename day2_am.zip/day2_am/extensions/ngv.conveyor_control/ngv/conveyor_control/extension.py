"""FloatDrag의 model 값이 바뀌면 해당 Action Graph 입력을 바로 갱신합니다."""

import functools

import carb
import omni.ext
import omni.kit.menu.utils
import omni.ui as ui

from .graph import PARAMETERS, attach_ramp, detach_ramp, read_parameters, scene_units, write_parameter

TITLE = "NGV Conveyor Control"


class ConveyorControlExtension(omni.ext.IExt):
    def on_startup(self, ext_id):
        self._window = None
        self._models = {}
        self._callbacks = []
        self._updating = False
        self._status = None
        self._menu = [omni.kit.menu.utils.MenuItemDescription(name=TITLE, onclick_fn=self._show_window)]
        omni.kit.menu.utils.add_menu_items(self._menu, "Window")
        self._show_window()

    def _show_window(self):
        if self._window is not None:
            self._window.visible = True
            return
        self._window = ui.Window(TITLE, width=480, height=420)
        with self._window.frame:
            # margin style을 자식에게 상속하지 않고 Spacer로 바깥 여백만 만듭니다.
            with ui.VStack(spacing=0):
                ui.Spacer(height=10)
                with ui.HStack(spacing=0):
                    ui.Spacer(width=12)
                    with ui.ScrollingFrame(horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF):
                        with ui.VStack(spacing=8, height=0):
                            ui.Label("Lane01 | Contact -> Stop", height=24)
                            ui.Label("Drag numbers left / right. Double-click to type.", height=20)
                            for key, title, unit in (
                                ("run_speed", "Run Speed", "m/s"),
                                ("stop_speed", "Stop Speed", "m/s"),
                                ("acceleration", "Acceleration", "m/s²"),
                                ("deceleration", "Deceleration", "m/s²"),
                            ):
                                _, default, upper = PARAMETERS[key]
                                with ui.HStack(height=26, spacing=8):
                                    ui.Label(title, width=112)
                                    model = ui.FloatDrag(width=ui.Fraction(1), min=0.0, max=upper, step=0.01, format="%.2f").model
                                    model.set_value(default)
                                    self._models[key] = model
                                    callback_id = model.add_value_changed_fn(functools.partial(self._changed, key))
                                    self._callbacks.append((model, callback_id))
                                    ui.Label(unit, width=42)
                            ui.Label("Stop Speed = 0: stop. Accel / Decel = 0: instant.", height=20)
                            with ui.HStack(height=28, spacing=6):
                                ui.Button("Connect Ramp", clicked_fn=self._connect)
                                ui.Button("Refresh from Graph", clicked_fn=self._refresh)
                            ui.Button("Remove Ramp", clicked_fn=self._remove, height=25)
                            self._status = ui.Label("Stop timeline, then Connect Ramp.", height=38, word_wrap=True)
                    ui.Spacer(width=12)
                ui.Spacer(height=10)
        self._refresh()

    def _set_status(self, message):
        if self._status is not None:
            self._status.text = str(message)

    def _error(self, error):
        carb.log_warn(f"[{TITLE}] {error}")
        self._set_status(error)

    def _load(self, values):
        self._updating = True
        try:
            for key, value in values.items():
                self._models[key].set_value(value)
        finally:
            self._updating = False

    def _changed(self, key, model):
        if self._updating:
            return
        try:
            write_parameter(key, model.as_float)
            self._set_status(f"Applied: {key} = {model.as_float:.2f}")
        except (RuntimeError, ValueError) as error:
            self._error(error)
            try:
                self._load(read_parameters())
            except RuntimeError:
                pass

    def _connect(self):
        try:
            self._load(attach_ramp())
            self._set_status("Connected. Play: accelerate; contact: decelerate.")
        except (RuntimeError, ValueError) as error:
            self._error(error)

    def _refresh(self):
        try:
            self._load(read_parameters())
            meters = scene_units()
            self._set_status("Values read from Graph. Stop timeline, then Connect Ramp." if meters == 1.0 else f"Stage unit = {meters:g} m. UI values use stage units/s and stage units/s².")
        except RuntimeError as error:
            self._set_status(error)

    def _remove(self):
        try:
            detach_ramp()
            self._set_status("Ramp removed. Contact now changes velocity immediately.")
        except (RuntimeError, ValueError) as error:
            self._error(error)

    def on_shutdown(self):
        omni.kit.menu.utils.remove_menu_items(self._menu, "Window")
        for model, callback_id in self._callbacks:
            model.remove_value_changed_fn(callback_id)
        self._callbacks.clear()
        self._models.clear()
        if self._window is not None:
            self._window.destroy()
            self._window = None
        self._status = None
        self._menu = None
