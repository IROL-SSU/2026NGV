"""이미 만들어 둔 Lane01ActionGraph에 RampSpeed를 연결하거나 해제합니다."""

import math
from pathlib import Path

import omni.graph.core as og
import omni.timeline
import omni.usd
from pxr import Gf, Sdf, UsdGeom

GRAPH_PATH = "/World/Graphs/Lane01ActionGraph"
BELTS = ("conveyor_belt", "conveyor_belt_01", "conveyor_belt_02")
PARAMETERS = {
    "run_speed": ("LabRunSpeed.inputs:value", 1.0, 10.0),
    "stop_speed": ("LabStopSpeed.inputs:value", 0.0, 10.0),
    "acceleration": ("RampSpeed.inputs:acceleration", 0.5, 20.0),
    "deceleration": ("RampSpeed.inputs:deceleration", 2.0, 20.0),
}


def _stage(stage=None):
    stage = stage or omni.usd.get_context().get_stage()
    if stage is None or not stage.GetPrimAtPath(GRAPH_PATH).IsValid():
        raise RuntimeError("Lane01ActionGraph가 없습니다. 먼저 tutorial 1~3을 준비하세요.")
    return stage


def _path(name):
    return f"{GRAPH_PATH}/{name}"


def _stopped():
    if not omni.timeline.get_timeline_interface().is_stopped():
        raise RuntimeError("먼저 timeline의 Stop 버튼을 누르세요. Pause에서는 연결하지 않습니다.")


def _execution_source(stage):
    if stage.GetPrimAtPath(_path("ContactEventLatch")).IsValid():
        return _path("ContactEventLatch.outputs:execOut")
    return _path("on_playback_tick.outputs:tick")


def _replace_input(source, destination):
    """기존 입력 연결을 제거한 뒤 하나의 source만 연결합니다."""
    target = og.Controller.attribute(destination)
    if not target.is_valid():
        raise RuntimeError(f"Graph 입력을 찾지 못했습니다: {destination}")
    for upstream in list(target.get_upstream_connections()):
        og.Controller.disconnect(upstream, target)
    og.Controller.connect(og.Controller.attribute(source), target)


def _cleanup_script_node(node):
    """연결 변경으로 무효화된 Script Node database를 복구한 뒤 구독을 정리합니다."""
    if not og.Controller.get(node.get_attribute("state:omni_initialized")):
        return
    from omni.graph.scriptnode.ogn.OgnScriptNodeDatabase import OgnScriptNodeDatabase
    from omni.graph.scriptnode.ogn.python.nodes.OgnScriptNode import OgnScriptNode

    data = OgnScriptNodeDatabase.PER_NODE_DATA[node.node_id()]
    if data.get("_db") is None:
        # Isaac Sim 6.2의 generated compute가 사용하는 동일한 복구 순서입니다.
        data["_db"] = OgnScriptNodeDatabase(node)
    OgnScriptNode.try_cleanup(node)


def attach_ramp(stage=None):
    """Stop 상태에서 한 번 실행. 기존 parameter 값은 보존합니다."""
    _stopped()
    stage = _stage(stage)
    required = ("LabRunSpeed", "LabStopSpeed", "LabSelectSpeed", "on_playback_tick") + BELTS
    for name in required:
        if not stage.GetPrimAtPath(_path(name)).IsValid():
            raise RuntimeError(f"필요한 node가 없습니다: {name}")
    ramp_path = _path("RampSpeed")
    created = not stage.GetPrimAtPath(ramp_path).IsValid()
    if created:
        og.Controller.edit(GRAPH_PATH, {og.Controller.Keys.CREATE_NODES: [("RampSpeed", "omni.graph.scriptnode.ScriptNode")]})
    ramp = og.Controller.node(ramp_path)
    if ramp.get_type_name() != "omni.graph.scriptnode.ScriptNode":
        raise RuntimeError("RampSpeed라는 다른 종류의 node가 이미 있습니다.")
    if not created and not stage.GetPrimAtPath(ramp_path).GetCustomDataByKey("ngv:conveyorRamp"):
        raise RuntimeError("다른 Script Node가 RampSpeed 이름을 사용 중입니다.")
    _cleanup_script_node(ramp)  # 선을 다시 연결하기 전에 기존 구독부터 정리합니다.

    input_port = og.AttributePortType.ATTRIBUTE_PORT_TYPE_INPUT
    output_port = og.AttributePortType.ATTRIBUTE_PORT_TYPE_OUTPUT
    for name, base_type, port in (
        ("inputs:targetVelocity", og.BaseDataType.FLOAT, input_port),
        ("inputs:deltaSeconds", og.BaseDataType.DOUBLE, input_port),
        ("inputs:simulationTime", og.BaseDataType.DOUBLE, input_port),
        ("inputs:acceleration", og.BaseDataType.FLOAT, input_port),
        ("inputs:deceleration", og.BaseDataType.FLOAT, input_port),
        ("outputs:velocity", og.BaseDataType.FLOAT, output_port),
    ):
        if not ramp.get_attribute_exists(name):
            og.Controller.create_attribute(ramp, name, og.Type(base_type), port)

    # Script를 USD 안에 넣어 scene을 다른 폴더로 옮겨도 실행되게 합니다.
    script = Path(__file__).with_name("ramp_script.py").read_text(encoding="utf-8")
    og.Controller.set(ramp.get_attribute("inputs:usePath"), False)
    if og.Controller.get(ramp.get_attribute("inputs:script")) != script:
        og.Controller.set(ramp.get_attribute("inputs:script"), script)
    if created:
        for key in ("acceleration", "deceleration"):
            suffix, default, _ = PARAMETERS[key]
            og.Controller.set(og.Controller.attribute(_path(suffix)), default)

    for source, destination in (
        (_path("LabSelectSpeed.outputs:result"), _path("RampSpeed.inputs:targetVelocity")),
        (_path("on_playback_tick.outputs:deltaSeconds"), _path("RampSpeed.inputs:deltaSeconds")),
        (_path("on_playback_tick.outputs:time"), _path("RampSpeed.inputs:simulationTime")),
        (_execution_source(stage), _path("RampSpeed.inputs:execIn")),
    ):
        _replace_input(source, destination)
    for belt in BELTS:
        _replace_input(_path("RampSpeed.outputs:velocity"), _path(f"{belt}.inputs:velocity"))
        _replace_input(_path("RampSpeed.outputs:execOut"), _path(f"{belt}.inputs:onStep"))
    prim = stage.GetPrimAtPath(ramp_path)
    prim.CreateAttribute("ui:nodegraph:node:pos", Sdf.ValueTypeNames.Float2).Set(Gf.Vec2f(650, 100))
    prim.SetCustomDataByKey("ngv:conveyorRamp", True)
    return read_parameters(stage)


def detach_ramp(stage=None):
    """Ramp를 제거하고 tutorial 1~3의 즉시 속도 변경 연결로 복구합니다."""
    _stopped()
    stage = _stage(stage)
    ramp = stage.GetPrimAtPath(_path("RampSpeed"))
    if not ramp.IsValid():
        return
    if not ramp.GetCustomDataByKey("ngv:conveyorRamp"):
        raise RuntimeError("이 extension이 만든 RampSpeed가 아니므로 제거하지 않습니다.")
    _cleanup_script_node(og.Controller.node(_path("RampSpeed")))
    for belt in BELTS:
        _replace_input(_path("LabSelectSpeed.outputs:result"), _path(f"{belt}.inputs:velocity"))
        _replace_input(_execution_source(stage), _path(f"{belt}.inputs:onStep"))
    og.Controller.edit(GRAPH_PATH, {og.Controller.Keys.DELETE_NODES: ["RampSpeed"]})


def read_parameters(stage=None):
    stage = _stage(stage)
    result = {}
    for key, (suffix, default, _) in PARAMETERS.items():
        attr = stage.GetAttributeAtPath(_path(suffix))
        value = attr.Get() if attr else None
        result[key] = float(value) if value is not None else default
    return result


def write_parameter(key, value, stage=None):
    stage = _stage(stage)
    suffix, _, upper = PARAMETERS[key]
    value = float(value)
    if not math.isfinite(value) or not 0.0 <= value <= upper:
        raise ValueError(f"0 이상 {upper:g} 이하의 유한한 값을 입력하세요.")
    if not stage.GetAttributeAtPath(_path(suffix)):
        raise RuntimeError("먼저 Stop 후 Connect Ramp를 누르세요.")
    attribute = og.Controller.attribute(_path(suffix))
    if not attribute.is_valid():
        raise RuntimeError("먼저 Stop 후 Connect Ramp를 누르세요.")
    og.Controller.set(attribute, value)


def scene_units(stage=None):
    return float(UsdGeom.GetStageMetersPerUnit(_stage(stage)))
