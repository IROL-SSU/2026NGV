"""RampSpeed의 Script 필드에 그대로 저장되는 코드. 외부 extension import 불필요."""

import math  # NaN과 infinity를 제외합니다.
import omni.timeline  # Stop 시 속도 상태를 초기화합니다.


def advance_velocity(current, target, dt, acceleration, deceleration):
    """한 frame 동안 목표에 가까워지며, 목표 속도를 지나치지 않습니다."""
    values = (current, target, dt, acceleration, deceleration)
    if not all(math.isfinite(float(value)) and value >= 0.0 for value in values):
        raise ValueError("Ramp inputs must be finite and nonnegative")
    if dt == 0.0 or current == target:
        return current  # 시간이 지나지 않았으면 움직임도 진행하지 않습니다.
    rate = acceleration if target > current else deceleration  # 증가/감소 방향을 구분합니다.
    if rate == 0.0:
        return target  # UI에서 0은 ramp 없이 즉시 변경하는 설정입니다.
    change = rate * dt  # 이번 frame에서 바뀔 수 있는 속도의 최대 크기입니다.
    return min(target, current + change) if target > current else max(target, current - change)


def setup(db):
    state = db.per_instance_state  # 이 Script Node만 사용하는 현재 속도입니다.
    state.velocity = 0.0
    state.last_time = None

    def on_timeline_event(event):
        if event.type == int(omni.timeline.TimelineEventType.STOP):
            state.velocity = 0.0  # 다음 Play는 0에서 가속합니다.
            state.last_time = None

    state.timeline_subscription = (
        omni.timeline.get_timeline_interface()
        .get_timeline_event_stream()
        .create_subscription_to_pop(on_timeline_event, name="NGV RampSpeed reset")
    )


def compute(db):
    state = db.per_instance_state
    now = float(db.inputs.simulationTime)
    if state.last_time is not None and now < state.last_time:
        state.velocity = 0.0  # timeline을 처음으로 되돌린 경우도 초기화합니다.
    state.last_time = now
    try:
        state.velocity = advance_velocity(
            state.velocity,
            float(db.inputs.targetVelocity),
            float(db.inputs.deltaSeconds),
            float(db.inputs.acceleration),
            float(db.inputs.deceleration),
        )
    except ValueError as error:
        db.log_error(str(error))
        state.velocity = 0.0
    db.outputs.velocity = state.velocity  # 이후 실행되는 세 conveyor가 같은 값을 받습니다.
    return True  # Script Node의 기본 Exec Out이 conveyor를 실행합니다.


def cleanup(db):
    state = db.per_instance_state
    subscription = getattr(state, "timeline_subscription", None)
    if subscription is not None:
        subscription.unsubscribe()  # node 삭제/재설정 때 event 구독을 정리합니다.
    state.timeline_subscription = None
