"""Kit 없이 실행: python -m unittest discover -s tests -v"""

import importlib.util
import math
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest


class Subscription:
    def __init__(self, callback):
        self.callback = callback
        self.active = True

    def unsubscribe(self):
        self.active = False


class Timeline:
    def __init__(self):
        self.subscriptions = []

    def get_timeline_event_stream(self):
        return self

    def create_subscription_to_pop(self, callback, name):
        subscription = Subscription(callback)
        self.subscriptions.append(subscription)
        return subscription


timeline = Timeline()
omni_stub = ModuleType("omni")
timeline_stub = ModuleType("omni.timeline")
timeline_stub.TimelineEventType = SimpleNamespace(STOP=2)
timeline_stub.get_timeline_interface = lambda: timeline
omni_stub.timeline = timeline_stub
sys.modules["omni"] = omni_stub
sys.modules["omni.timeline"] = timeline_stub
script_path = Path(__file__).resolve().parents[1] / "ngv/conveyor_control/ramp_script.py"
spec = importlib.util.spec_from_file_location("ramp_under_test", script_path)
ramp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ramp)


class RampTests(unittest.TestCase):
    def test_acceleration_reaches_one_in_two_seconds(self):
        value = 0.0
        for _ in range(120):
            value = ramp.advance_velocity(value, 1.0, 1.0 / 60, 0.5, 2.0)
        self.assertAlmostEqual(value, 1.0)

    def test_contact_decelerates_in_half_second(self):
        value = 1.0
        for _ in range(30):
            value = ramp.advance_velocity(value, 0.0, 1.0 / 60, 0.5, 2.0)
        self.assertAlmostEqual(value, 0.0)

    def test_target_never_overshoots(self):
        self.assertEqual(ramp.advance_velocity(0.9, 1.0, 0.5, 1.0, 2.0), 1.0)
        self.assertEqual(ramp.advance_velocity(0.1, 0.0, 0.5, 1.0, 2.0), 0.0)

    def test_zero_rate_is_instant(self):
        self.assertEqual(ramp.advance_velocity(0.0, 1.0, 0.1, 0.0, 2.0), 1.0)
        self.assertEqual(ramp.advance_velocity(1.0, 0.0, 0.1, 0.5, 0.0), 0.0)

    def test_zero_time_keeps_current(self):
        self.assertEqual(ramp.advance_velocity(0.4, 1.0, 0.0, 0.5, 2.0), 0.4)

    def test_nonzero_stop_speed_and_target_changes(self):
        self.assertAlmostEqual(ramp.advance_velocity(1.0, 0.2, 0.2, 0.5, 2.0), 0.6)
        self.assertAlmostEqual(ramp.advance_velocity(0.6, 2.0, 0.2, 0.5, 2.0), 0.7)

    def test_invalid_values_are_rejected(self):
        for bad in (-1.0, math.nan, math.inf):
            for index in range(5):
                values = [0.0, 1.0, 0.1, 0.5, 2.0]
                values[index] = bad
                with self.assertRaises(ValueError):
                    ramp.advance_velocity(*values)

    def test_stop_and_cleanup(self):
        db = SimpleNamespace(
            per_instance_state=SimpleNamespace(),
            inputs=SimpleNamespace(simulationTime=0.1, targetVelocity=1.0, deltaSeconds=0.1, acceleration=0.5, deceleration=2.0),
            outputs=SimpleNamespace(),
        )
        ramp.setup(db)
        ramp.compute(db)
        self.assertAlmostEqual(db.outputs.velocity, 0.05)
        sub = db.per_instance_state.timeline_subscription
        sub.callback(SimpleNamespace(type=2))
        self.assertEqual(db.per_instance_state.velocity, 0.0)
        ramp.compute(db)
        self.assertAlmostEqual(db.outputs.velocity, 0.05)
        ramp.cleanup(db)
        self.assertFalse(sub.active)
        self.assertIsNone(db.per_instance_state.timeline_subscription)


if __name__ == "__main__":
    unittest.main()
